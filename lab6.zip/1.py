import random

def generate_tuple(start, end, size):
   return tuple(random.randint(start, end) for _ in range(size))

tuple1 = generate_tuple(0, 5, 10)
tuple2 = generate_tuple(-5, 0, 10)
tuple3 = tuple1 + tuple2

count = tuple3.count(0)

print("Первый кортеж:", tuple1)
print("Второй кортеж:", tuple2)
print("Третий кортеж:", tuple3)
print("Количество нулей в третьем кортеже:", count)