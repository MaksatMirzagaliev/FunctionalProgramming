kazakh_alphabet = {
   "а": "a",
   "ә": "á",
   "б": "b",
   "в": "v",
   "г": "g",
   "ғ": "ǵ",
   "д": "d",
   "е": "e",
   "ё": "io",
   "ж": "j",
   "з": "z",
   "и": "i",
   "й": "i",
   "к": "k",
   "қ": "q",
   "л": "l",
   "м": "m",
   "н": "n",
   "ң": "ń",
   "о": "o",
   "ө": "ó",
   "п": "p",
   "р": "r",
   "с": "s",
   "т": "t",
   "у": "y",
   "ұ": "u",
   "ү": "ú",
   "ф": "f",
   "х": "h",
   "һ": "h",
   "ц": "ts",
   "ч": "ch",
   "ш": "sh",
   "щ": "sch",
   "ъ": "",
   "ы": "y",
   "і": "i",
   "ь": "",
   "э": "e",
   "ю": "iu",
   "я": "ia"
}

input_text = input("Введите текст на казахском языке: ")

latin_text = ""
for char in input_text:
   if char.lower() in kazakh_alphabet:
      latin_text += kazakh_alphabet[char.lower()]
   else:
      latin_text += char

print("Текст на латинице: ", latin_text)