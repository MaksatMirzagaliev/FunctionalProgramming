expenses = [
   [0, 0, 0, 0, 0],  
   [0, 0, 0, 0, 0], 
   [0, 0, 0, 0, 0],  
   [0, 0, 0, 0, 0],  
   [0, 0, 0, 0, 0],  
   [0, 0, 0, 0, 0], 
   [0, 0, 0, 0, 0]  
]

categories = ["Транспортные расходы", "Обед", "Продукты", "Развлечения", "Другое"]

for i in range(len(expenses)):
   print("День недели:", i+1)
   for j in range(len(categories)):
      expense = float(input("Введите расходы по категории '{}' для этого дня недели: ".format(categories[j])))
      expenses[i][j] = expense

total_expenses = 0
for i in range(len(expenses)):
   for j in range(len(categories)):
      total_expenses += expenses[i][j]

print("Общий объем расходов за неделю:", total_expenses)