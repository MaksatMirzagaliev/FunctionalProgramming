set1 = {"Erzhan Ali", 20, "MUIT", "He lives in Almaty"}
set2 = {"MUIT", "В данный момент не работает"}
set1.add(2003)
print(set1)
set1.remove(20)
print(set1)
set3 = set1.union(set2)
print(set3)
set3 = set1.intersection(set2)
print(set3)
set2.update(["Родился в 2003 году", "Нет судимости", "Не женат"])
print(set2)