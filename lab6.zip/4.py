input_str = input("Введите имена студентов через пробел: ")
names = tuple(input_str.split())

names_with_va = [name for name in names if "Ва" in name]
print("Имена, содержащие фрагмент 'ва':", " ".join(names_with_va))