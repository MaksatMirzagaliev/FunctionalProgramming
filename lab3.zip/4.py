valid_input = False

while not valid_input:
   num1 = input("Введите первое число: ")
   # проверяем, состоит ли введенная строка только из цифр
   if num1.isdigit():
      num1 = int(num1)
      valid_input = True
   else:
      print("Ошибка: введенное значение не является целым числом.")

valid_input = False

while not valid_input:
   num2 = input("Введите второе число: ")
   # проверяем, состоит ли введенная строка только из цифр
   if num2.isdigit():
      num2 = int(num2)
      valid_input = True
   else:
      print("Ошибка: введенное значение не является целым числом.")

# выводим сумму двух чисел
print("Сумма чисел:", num1 + num2)
