N = 10
card_numbers = [1, 2, 3, 4, 5, 6, 8, 9, 10]  # список номеров карточек

# вычисляем сумму всех номеров карточек
total_sum = N * (N + 1) / 2

# вычисляем сумму номеров оставшихся карточек
remaining_sum = sum(card_numbers)

# вычисляем номер потерянной карточки
lost_card_number = int(total_sum - remaining_sum)

print("Номер потерянной карточки:", lost_card_number)