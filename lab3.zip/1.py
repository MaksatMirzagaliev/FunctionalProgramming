A = 12
B = 4

if A < B:
   print("Числа в порядке возрастания")
   for i in range(A, B):
      print(i)
else:
      print("Числа в порядке убывания")
      for i in range(A, B-1, -1):
         print(i)