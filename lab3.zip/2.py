A = 10
B = 1

for i in range(A, B-1, -1):
   if i % 2 == 1:
      print(i)