a = 5
b = 12
i = a
while i <= b:
   print(i)
   i += 1