import random
print(random.random())
print(random.random())
print(random.randrange(3, 100, 10))
print(random.randrange(3, 100, 10))
print(random.randint(0, 5))
print(random.randint(0, 5))

shopping_list = ["fruits", "cookies","cereals", "protein bars", "post-it notes"]
for index, item in enumerate(shopping_list):
   print(f"index:{index}, item:{item}")