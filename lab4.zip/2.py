a = 0
while a < 10:
   a += 1
   print(a)