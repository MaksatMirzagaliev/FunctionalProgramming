my_list = list(range(1, 10, 2)) + list(range(0, -5, -1)) + list(range(10, 21))
print(my_list)