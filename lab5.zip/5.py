import random

numbers = list(range(1, 50))

winning_numbers = random.sample(numbers, 6)

winning_numbers.sort()

print("Выигрышные номера билета:", winning_numbers)