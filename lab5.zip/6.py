def is_sorted(lst):
   return lst == sorted(lst) or lst == sorted(lst, reverse=True)

user_input = input("Введите список чисел через запятую: ")
lst = [int(x) for x in user_input.split(",")]

if is_sorted(lst):
   print("Список отсортирован.")
else:
   print("Список не отсортирован.")