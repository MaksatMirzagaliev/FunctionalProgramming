my_portfolio = ["Khan Vyaceslav", 19, "Student"]
my_portfolio.append("Satbayev University")
my_portfolio.extend(["Hello World", "work"])
for i in my_portfolio:
   print(i)
my_portfolio.remove("Hello World")
my_portfolio.pop()
print()
for i in my_portfolio:
   print(i)
print()
print(len(my_portfolio))