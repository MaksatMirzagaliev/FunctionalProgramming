numbers = []

while True:
   number = int(input("Введите целое число (0 для завершения): "))
   if number == 0:
      break
   numbers.append(number)

sorted_numbers = sorted(numbers)

for number in sorted_numbers:
   print(number)