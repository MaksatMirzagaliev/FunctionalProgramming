students = ["Maksat", "Erzhan", "Erbol"]
lessons = ["Functional Programming", "OOP", "Data Analysis"]
dist = {
   students[0]: {8, 5, 9}, 
   students[1]: {10, 10, 10}, 
   students[2]: {2, 1, 3}
   }
Student_name = input("input Student's name: ")
print(lessons)
print(dist[Student_name])