students = []

num_students = int(input("count of students:  "))

for i in range(num_students):
   name = input("input student's name: ")
   group_name = input("input group: ")
   subject = input("inputr subject: ")
   students.append((name, group_name, subject))

sort = sorted(students, key=lambda x: x[1])

for student in sort:
   print(f"Name:{student[0]} -Group:{student[1]} -Subject:{student[2]}")