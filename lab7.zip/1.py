n = int(input("введите число стран в словаре: "))

country_rivers = {}

for i in range(n):
   line = input().split()
   country = line[0]
   rivers = line[1:]
   country_rivers[country] = rivers

rivers_list = input("Реки в словаре: ").split()

for river in rivers_list:
   found = False
   for country, rivers in country_rivers.items():
      if river in rivers:
            print(river, country)
            found = True
   if not found:
      print(river, "такой реки не обнаружена")

if any(river in rivers for rivers in country_rivers.values() for river in rivers_list):
   print("Есть")
else:
   print("Нет")
