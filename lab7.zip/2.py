commentators = {}
print("Автор коммента: Введенный текст")
while True:
   line = input("")
   if line == "":
      break
   name, comment = line.split(": ")
   commentators[name] = comment

print(len(commentators))