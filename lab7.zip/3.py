n = int(input("Количество номеров, которых вы хотите добавить: "))
phonebook = {}
for i in range(n):
   name, phone = input().split()
   phonebook[name] = phone

print(phonebook.keys())
query = input("Введите имя для проверки: ")

if query in phonebook.keys():
   print(phonebook[query])
else:
   print("Нет в телефонной книге")