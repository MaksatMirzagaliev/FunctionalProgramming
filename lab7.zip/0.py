my_portfolio = {'name': "Mirzagaliev Maksat", 'age': 19, 'place of study': "Satbayev University"}
my_portfolio['height'] = "170"
print(my_portfolio)
reserve_portfolio = my_portfolio.copy()
print(reserve_portfolio)
reserve_portfolio.pop('name')
print(reserve_portfolio)
print(my_portfolio.items())
print(my_portfolio.keys())
print(my_portfolio.values())