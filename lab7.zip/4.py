n = int(input("число сотрудников:"))
vacations = {}
print("Имя день месяц")
for i in range(n):
   name, day, month = input().split()
   if month not in vacations:
      vacations[month] = []
   vacations[month].append(name)

query_month = input("Введите месяц: ")
if query_month in vacations:
   print(vacations[query_month])
else:
   print('')